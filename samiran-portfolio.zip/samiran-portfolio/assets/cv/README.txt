Place your CV PDF here. Keep the filename Samiran_Patra_CV.pdf or update the link in index.html.
