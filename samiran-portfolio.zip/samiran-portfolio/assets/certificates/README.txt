Place your internship/training certificate PDFs here. Update filenames in index.html to match your files.
