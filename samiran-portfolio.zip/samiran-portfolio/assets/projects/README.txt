Place project screenshots and preview images here. Update js/projects.js and index.html if you want to display them.
